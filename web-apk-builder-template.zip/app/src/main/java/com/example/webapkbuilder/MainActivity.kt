package com.example.webapkbuilder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.URLUtil
import android.widget.*

class MainActivity : Activity() {
    private lateinit var name: EditText
    private lateinit var source: EditText
    private var iconUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40,40,40,40)
        }

        root.addView(TextView(this).apply {
            text = "Web APK Builder"
            textSize = 28f
        })

        name = EditText(this).apply { hint = "APK / App name" }
        root.addView(name)

        root.addView(Button(this).apply {
            text = "Choose icon"
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "image/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }, 100)
            }
        })

        source = EditText(this).apply {
            hint = "Paste URL or HTML code here"
            minLines = 8
            gravity = android.view.Gravity.TOP
        }
        root.addView(source)

        root.addView(Button(this).apply {
            text = "Choose HTML file"
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "text/html"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }, 101)
            }
        })

        root.addView(Button(this).apply {
            text = "Build APK"
            setOnClickListener { prepareBuildConfig() }
        })

        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        if (requestCode == 100) iconUri = data.data
        if (requestCode == 101) source.setText(data.data.toString())
    }

    private fun prepareBuildConfig() {
        val appName = name.text.toString().trim()
        val content = source.text.toString().trim()
        if (appName.isEmpty()) { name.error = "Enter an app name"; return }
        if (content.isEmpty()) { source.error = "Enter a URL or HTML source"; return }

        val mode = when {
            URLUtil.isValidUrl(content) -> "url"
            content.startsWith("<") -> "html"
            else -> "html_file_or_source"
        }

        val config = """
        {
          "appName": "${escape(appName)}",
          "sourceMode": "$mode",
          "source": "${escape(content)}",
          "iconUri": "${escape(iconUri?.toString() ?: "")}"
        }
        """.trimIndent()

        getPreferences(MODE_PRIVATE).edit().putString("lastConfig", config).apply()
        Toast.makeText(this, "Build configuration prepared", Toast.LENGTH_LONG).show()
    }

    private fun escape(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
}
