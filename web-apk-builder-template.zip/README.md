# Web APK Builder

Prototype native Android builder. It collects app name, icon, URL/HTML source and prepares a build configuration. The final packaging worker will run in a build environment such as GitHub Actions.
